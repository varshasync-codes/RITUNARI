RITUNAARI FULL-STACK DEMO (Frontend + FastAPI Backend)

FRONTEND FILES
index.html, about.html, features.html, contact.html, cycle-tracker.html, style.css, script.js

BACKEND FILES
backend/main.py             FastAPI API, signup/login, contact feedback, SQLite database
backend/requirements.txt    Python packages required by the backend
backend/.env.example        Environment configuration template

RUN THE BACKEND (Windows / VS Code)
1. Install Python 3.11 or newer.
2. Open a terminal in this project folder.
3. Run:
   cd backend
   py -m venv .venv
   .venv\Scripts\activate
   py -m pip install -r requirements.txt
4. Copy .env.example to .env and set RITUNAARI_SECRET_KEY to a long random secret.
5. Start the server:
   uvicorn main:app --reload --host 127.0.0.1 --port 8000
6. Test the API at http://127.0.0.1:8000/docs and health at http://127.0.0.1:8000/api/health

RUN THE FRONTEND
1. Open the project root (the folder containing index.html) in VS Code.
2. Use the Live Server extension on index.html. Common URL: http://127.0.0.1:5500/index.html
3. Keep the backend terminal running at the same time.
4. Signup/login calls /api/register and /api/login. Contact form posts to /api/contact.
5. SQLite creates backend/ritunaari.db automatically when the API starts.

IMPORTANT
- The cycle tracker deliberately remains browser-only and does not send menstrual data to the backend.
- This is a learning/demo setup. Before real deployment, use HTTPS, a strong secret, strict CORS, rate limiting, secure deployment secrets, privacy policy/consent, backups and security review.
- Contact messages contain personal information; use test data during demonstrations and delete the local database when no longer needed.
- Do not expose backend/.env or backend/ritunaari.db publicly.


INTERACTIVE UPDATE
- Place the Ritunaari logo at images/logo.png (included).
- Features page cards open learning guides and short multiple-choice quizzes.
- Floating Ritu companion is a scripted guide, not an AI model or medical service.
- Open index.html using VS Code Live Server. Keep the backend steps below for signup/login/contact API.


NEW FEATURE: PCOS Symptom-to-Guidance prototype
- Open symptom-guide.html using VS Code Live Server (recommended).
- Start the API from the backend folder (commands below).
- The guide sends a symptom description to POST /api/symptom-guide; this endpoint does not store symptom data.
- If the API is not running, the page uses a local rule-based fallback for demo purposes.
- This is an educational prototype, not a validated clinical tool or diagnostic model.

BACKEND START (Windows PowerShell, from the project folder):
  py -m venv .venv
  .venv\Scripts\Activate.ps1
  pip install -r backend\requirements.txt
  cd backend
  copy .env.example .env
  uvicorn main:app --reload

Then open http://127.0.0.1:8000/docs to test the API. Run the frontend separately with VS Code Live Server, usually at http://127.0.0.1:5500.
