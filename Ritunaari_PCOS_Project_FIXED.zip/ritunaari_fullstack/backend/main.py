"""Ritunaari demo backend: FastAPI + SQLite + JWT authentication."""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Literal

import jwt
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, Header, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr, Field

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
DB_PATH = Path(os.getenv("RITUNAARI_DB_PATH", str(BASE_DIR / "ritunaari.db")))
JWT_SECRET = os.getenv("RITUNAARI_SECRET_KEY", "")
JWT_ALGORITHM = "HS256"
TOKEN_MINUTES = int(os.getenv("RITUNAARI_TOKEN_MINUTES", "120"))

if not JWT_SECRET:
    # For local development only. Set a long random secret in backend/.env.
    JWT_SECRET = secrets.token_urlsafe(48)
    print("WARNING: RITUNAARI_SECRET_KEY is not set. A temporary key is being used; sessions will expire after restart.")

app = FastAPI(title="Ritunaari API", version="1.0.0", description="Backend API for the Ritunaari educational demo")

# Add any frontend origin you use, for example http://127.0.0.1:5500.
allowed_origins = [
    item.strip() for item in os.getenv(
        "RITUNAARI_CORS_ORIGINS",
        "http://127.0.0.1:5500,http://localhost:5500,http://127.0.0.1:5501,http://localhost:5501"
    ).split(",") if item.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)


def connect_db() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS contact_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                subject TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.commit()


@app.on_event("startup")
def startup() -> None:
    init_db()


class RegisterInput(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginInput(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class ContactInput(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    email: EmailStr
    subject: Literal["feedback", "suggestion", "accessibility", "other"]
    message: str = Field(min_length=1, max_length=1500)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 310_000)
    return f"pbkdf2_sha256${salt.hex()}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, salt_hex, expected_hex = encoded.split("$", 2)
        if algorithm != "pbkdf2_sha256":
            return False
        actual = hash_password(password, bytes.fromhex(salt_hex)).split("$", 2)[2]
        return hmac.compare_digest(actual, expected_hex)
    except (ValueError, TypeError):
        return False


def create_access_token(user_id: int, email: str) -> str:
    expires = datetime.now(timezone.utc) + timedelta(minutes=TOKEN_MINUTES)
    return jwt.encode({"sub": str(user_id), "email": email, "exp": expires}, JWT_SECRET, algorithm=JWT_ALGORITHM)


def public_user(row: sqlite3.Row) -> dict:
    return {"id": row["id"], "name": row["name"], "email": row["email"]}


def current_user(authorization: str | None = Header(default=None)) -> dict:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Please log in first.")
    token = authorization.split(" ", 1)[1].strip()
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Session expired or invalid. Please log in again.")
    with connect_db() as conn:
        row = conn.execute("SELECT id, name, email FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User account was not found.")
    return public_user(row)


@app.get("/")
def root() -> dict:
    return {"name": "Ritunaari API", "docs": "/docs", "health": "/api/health"}


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "service": "ritunaari-api"}


@app.post("/api/register", status_code=201)
def register(data: RegisterInput) -> dict:
    name = data.name.strip()
    email = str(data.email).strip().lower()
    if not name:
        raise HTTPException(status_code=422, detail="Name is required.")
    try:
        with connect_db() as conn:
            cursor = conn.execute(
                "INSERT INTO users (name, email, password_hash, created_at) VALUES (?, ?, ?, ?)",
                (name, email, hash_password(data.password), now_iso()),
            )
            conn.commit()
            user_id = cursor.lastrowid
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="An account with this email already exists. Try logging in.")
    return {"message": "Account created successfully.", "access_token": create_access_token(user_id, email), "token_type": "bearer", "user": {"id": user_id, "name": name, "email": email}}


@app.post("/api/login")
def login(data: LoginInput) -> dict:
    email = str(data.email).strip().lower()
    with connect_db() as conn:
        row = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    if row is None or not verify_password(data.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Email or password is incorrect.")
    return {"message": "Logged in successfully.", "access_token": create_access_token(row["id"], row["email"]), "token_type": "bearer", "user": public_user(row)}


@app.get("/api/me")
def me(user: dict = Depends(current_user)) -> dict:
    return {"user": user}


@app.post("/api/contact", status_code=201)
def create_contact_message(data: ContactInput) -> dict:
    name, email, message = data.name.strip(), str(data.email).strip().lower(), data.message.strip()
    if not name or not message:
        raise HTTPException(status_code=422, detail="Name and message are required.")
    with connect_db() as conn:
        conn.execute(
            "INSERT INTO contact_messages (name, email, subject, message, created_at) VALUES (?, ?, ?, ?, ?)",
            (name, email, data.subject, message, now_iso()),
        )
        conn.commit()
    return {"message": "Thank you! Your feedback has been received."}


# Privacy-first symptom guidance prototype. Requests are processed in memory and never stored.
class SymptomGuideInput(BaseModel):
    description: str = Field(min_length=3, max_length=1200)
    duration: Literal["recent", "1-3-months", "3-months-plus", "unsure"] = "unsure"
    no_period_90_days: bool = False
    rapid_change: bool = False
    severe_warning_signs: list[str] = Field(default_factory=list, max_length=8)
    age_group: Literal["under-18", "18-plus", "prefer-not-to-say"] = "prefer-not-to-say"


@app.post("/api/symptom-guide")
def symptom_guide(data: SymptomGuideInput) -> dict:
    """Return educational pattern notes and care navigation, not a diagnosis."""
    text = data.description.lower()
    patterns = []
    checks = [
        (("irregular period", "irregular periods", "period irregular", "missed period", "missed periods", "late period", "late periods", "no period", "period stopped"), "Menstrual-cycle changes", "Cycle changes can be associated with PCOS, but stress, pregnancy, thyroid conditions, medicines and other factors can also affect periods."),
        (("facial hair", "chin hair", "upper lip hair", "body hair", "hair growth", "hirsutism"), "Increased facial or body hair", "Increased coarse hair can be associated with higher androgen levels, including in PCOS, but it is not specific to PCOS."),
        (("acne", "pimples", "breakouts"), "Acne", "Acne can occur with hormonal changes, including PCOS, and also has many other common causes."),
        (("hair thinning", "hair loss", "thinning hair", "scalp hair"), "Scalp hair thinning", "Hair thinning has several possible causes. A clinician can assess the pattern and whether hormone or other testing is appropriate."),
        (("dark skin", "dark patches", "skin patches", "velvety skin"), "Darkened skin patches", "Some skin changes can be associated with insulin resistance, but a skin change alone cannot establish its cause."),
        (("tired", "fatigue", "low energy", "exhausted"), "Tiredness or low energy", "Tiredness is common and nonspecific; sleep, iron levels, thyroid conditions, stress and other factors may be relevant."),
    ]
    for words, label, explanation in checks:
        if any(word in text for word in words):
            patterns.append({"label": label, "explanation": explanation})

    warning_map = {
        "severe-pain": "Severe or sudden pelvic/abdominal pain needs urgent medical assessment.",
        "fainting": "Fainting or feeling close to fainting with symptoms needs urgent medical assessment.",
        "heavy-bleeding": "Very heavy bleeding (for example, soaking through a pad or tampon each hour for 2 or more hours), especially with weakness or dizziness, needs urgent medical care.",
        "pregnancy-pain-bleeding": "If pregnancy is possible and you have pain or bleeding, seek prompt urgent medical assessment.",
        "fever": "Fever with pelvic pain or unusual discharge should be assessed promptly.",
    }
    selected_warnings = [warning_map[x] for x in data.severe_warning_signs if x in warning_map]
    if selected_warnings:
        urgency = "urgent"
        title = "Please prioritise medical care"
        next_steps = [*selected_warnings, "Do not rely on this tool to assess an urgent symptom. Contact local emergency services if symptoms are severe or you feel unsafe."]
    elif data.rapid_change:
        urgency = "prompt"
        title = "Arrange a prompt medical assessment"
        next_steps = ["Rapid changes in facial/body hair, scalp hair, or other hormone-related features deserve timely assessment.", "Tell the clinician when the change started and how quickly it has progressed."]
    elif data.no_period_90_days:
        urgency = "appointment"
        title = "Book a healthcare appointment"
        next_steps = ["Going about 90 days without a period merits medical assessment, particularly if periods were previously established.", "If pregnancy is possible, consider a pregnancy test and discuss the result with a healthcare professional."]
    elif patterns or data.duration in ("1-3-months", "3-months-plus"):
        urgency = "routine"
        title = "Consider a routine PCOS and menstrual-health assessment"
        next_steps = ["Book a routine appointment if symptoms persist, recur, or worry you.", "Bring a record of period dates, symptom changes, medicines, and relevant family history if you know it.", "A clinician may consider other causes and decide whether examination or tests are appropriate."]
    else:
        urgency = "information"
        title = "Gather a little more context"
        next_steps = ["Track when symptoms occur, how often, and whether they are changing.", "If symptoms persist, recur, or concern you, arrange a healthcare appointment."]

    if data.age_group == "under-18":
        next_steps.append("For teenagers, PCOS assessment needs particular care because normal puberty changes can overlap with symptoms. A qualified clinician can interpret symptoms in context.")
    if not patterns:
        patterns.append({"label": "No clear symptom keywords identified", "explanation": "The description may use words this prototype does not recognise. The tool cannot rule conditions in or out; clarify the symptoms with a healthcare professional if concerned."})
    return {
        "title": title,
        "urgency": urgency,
        "patterns": patterns,
        "next_steps": next_steps,
        "pcos_note": "These symptoms may overlap with PCOS but do not diagnose it. PCOS assessment depends on age and clinical context, and other causes may need to be considered.",
        "privacy": "This prototype processes this request in memory and does not save the symptom description to the database.",
        "disclaimer": "Educational care navigation only; not a diagnosis, probability score, or substitute for a qualified healthcare professional."
    }
